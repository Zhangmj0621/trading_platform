#ifndef MYTIME_H
#define MYTIME_H

#include<iostream>
using namespace std;

class MyTime
{
public:
    MyTime();

    static void getMyTime(string& a,int& day2);
};

#endif // MYTIME_H
