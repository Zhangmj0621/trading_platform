#ifndef READ_H
#define READ_H


class Read
{
public:
    Read();

    int readUser();
    int readModity();
    int readOrder();
};

#endif // READ_H
