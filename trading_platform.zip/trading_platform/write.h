#ifndef WRITE_H
#define WRITE_H


class Write
{
public:
    Write();

    void writeUser();

    void writeModity();

    void writeOrder();
};

#endif // WRITE_H
