#include"dialog.h"

Dialog::Dialog()
{

}
